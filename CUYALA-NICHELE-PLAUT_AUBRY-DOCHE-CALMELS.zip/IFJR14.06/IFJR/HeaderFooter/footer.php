<div class="footer">
  <ul class="footer row"> <!-- Ajout de la classe "row" -->
    <li class="footer"><a class="footer" href="https://www.justicerestaurative.org/category/actualite/">ACTUALITÉS DE L'INSTITUT</a></li>
    <li class="footer"><a class="footer" href="https://www.justicerestaurative.org/espace-presse/">ESPACE PRESSE</a></li>
    <li class="footer"><a class="footer" href="https://www.justicerestaurative.org/politique-de-confidentialite/">POLITIQUE DE CONFIDENTIALITÉ</a></li>
  </ul>
  <p class="footer row">&copy; 2023 CY-Tech</p> <!-- Ajout de la classe "row" -->
</div>
