<!DOCTYPE html>
<html lang="fr">
  <head>
    <meta charset="UTF-8" />
    <meta name="description" content="IFJR">
    <meta name="author" content="PLAUT-AUBRY Baptiste">
    <link rel="stylesheet" href="../CSS/Fichettes.css">
    <link rel="stylesheet" href="../HeaderFooter/header.css">
    <link rel="stylesheet" href="../HeaderFooter/footer.css">
    <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
    <title>Frontpage</title>
  </head>

<main>
<header>
  <?php
    include("../HeaderFooter/header.php");
  ?>
</header>


  <body>
    <div class="wrapper">
      <h2 class="title"><center>FORMATIONS</center></h2>
      <div class="container-fluid">
        <br>
        <div class="block_line">
          <div class="container-box1 block" id="box"> <!-- PREMIERE BOX -->
              <a href="../Formations/NosFormations.php">
                <div class="block_content">
                  <h3> Formations: </h3>
                  <div><em>Retrouvez les formations proposées par nos partenaires<span class = "arrow"></span></em></div>
                </div>
              </a>
          </div> <!-- FIN PREMIERE BOX -->

          <div class="container-box2 block" id="box"> <!-- DEUXIEME BOX -->
              <a href="../Informations/InfoIFJR.php">
                <div class="block_content">
                  <h3> Informations</h3>
                  <div><em>Pour plus d'informations sur l'IFJR<span class = "arrow"></span></em></div>
                </div>
                </a>
          </div> <!-- FIN DEUXIEME BOX -->

          <div class="container-box3 block" id="box"> <!-- TROISIEME BOX -->

              <a href="../Carte/TrouverCorrespondant.php">
                <div class="block_content">
                  <h3>Trouver un correspondant</h3>
                  <div><em>Trouver la personne à contacter dans votre région<span class = "arrow"></span></em></div>
                  </div>
              </a>
          </div> <!-- FIN TROISIEME BOX -->
        </div>
        <br>
        <br>
      </div>

    </div>
      <script type="text/javascript" src="Fichettes.js"></script>  <!-- JS DE L'ANIMATION DES BOXS -->
  </body>
  </main>
<footer>
  <?php
    include("../HeaderFooter/footer.php");
  ?>
</footer>
</html>
