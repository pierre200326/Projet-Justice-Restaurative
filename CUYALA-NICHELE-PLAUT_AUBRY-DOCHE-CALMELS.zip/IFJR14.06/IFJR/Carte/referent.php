<!DOCTYPE html>
<html lang="fr">
  <head>
    <meta charset="UTF-8" />
    <meta name="description" content="IFJR">
    <meta name="author" content="PLAUT-AUBRY Baptiste">
    <link rel="stylesheet" href="../HeaderFooter/header.css">
    <link rel="stylesheet" href="../HeaderFooter/footer.css">
    <link rel="stylesheet" href="../CSS/Carte.css">
    <link rel="stylesheet" href="../CSS/Fichettes.css">
    <link rel="stylesheet" href="map.css">
    <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
    <title>Trouver un correspondant</title>
  </head>

<header>
  <?php
    include("../HeaderFooter/header.php");
  ?>
</header>

<main>
<body>
  <div class="wrapper">
    <h2 class="title">Trouver un correspondant dans votre département</h2>

    <div class="tooltipbarre">
    
    <?php
    include("resultat.php");
    ?>
    </div>
  
  </div>

  </div>
</body>
</main>


<footer>
  <?php
    include("../HeaderFooter/footer.php");
  ?>
</footer>

</html>
