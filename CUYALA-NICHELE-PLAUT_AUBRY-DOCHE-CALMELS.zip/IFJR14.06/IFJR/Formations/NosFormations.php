<!DOCTYPE html>
<html lang="fr">
  <head>
    <meta charset="UTF-8" />
    <meta name="description" content="IFJR">
    <meta name="author" content="PLAUT-AUBRY Baptiste">
    <link rel="stylesheet" href="../CSS/Fichettes.css">
    <link rel="stylesheet" href="../HeaderFooter/header.css">
    <link rel="stylesheet" href="../HeaderFooter/footer.css">
    <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
    <title>Formations</title>
  </head>


<header>
  <?php
    include("../HeaderFooter/header.php");
  ?>
</header>


<body>
  <div class="wrapper">
    <h2 class="title"><center>FORMATIONS</center></h2>
      <br>
    <div class="block_line_container">
            <?php 
            $row = 1;
            if (($handle = fopen("formation.csv", "r")) !== FALSE) {
                while (($data = fgetcsv($handle, 1000, ";")) !== FALSE) {
                    $num = count($data);
                    $cheminAdmin = $data[0]."Admin.php";
                    $chemin = $data[0].".php";
                    if($row==1){
                      echo '<div class="block_line">';
                    }
                    echo '<div class="container-box'.$row.' block" id="box">';
                    echo '<a href="'.$data[0].'.php">';
                    echo '<div class="block_content">';
                    echo '<h3> '.$data[0].': </h3>';
                    echo '<div><em>'.$data[1].'<span class = "arrow"></span></em></div>';
                    echo '</div>';
                    echo '</a>';
                    echo '</div>';
                    if($row==3){
                      echo '</div>';
                    }
                    if($row==3){
                      $row=1;
                    }else{
                      $row++;
                    }
                    if (!file_exists($chemin)) {
                      $texte = '<!DOCTYPE html>
            <html>
            <head>
    <meta charset="UTF-8" />
    <meta name="description" content="IFJR">
    <meta name="author" content="PLAUT-AUBRY Baptiste">
    <link rel="stylesheet" href="../CSS/InfoIFJR.css">
    <link rel="stylesheet" href="../CSS/Fichettes.css">
    <link rel="stylesheet" href="../HeaderFooter/header.css">
    <link rel="stylesheet" href="../HeaderFooter/footer.css">
    <link rel="stylesheet" href="../CSS/Formations.css">
    <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
    <title>Informations</title>
  </head>
  <main>
          <header>
            <?php
              include("../HeaderFooter/header.php");
            ?>
        </header>
                <body>
                
                <div class="name">
                  Formation : '.$data[0].' – '.$data[1].'
                </div>
                <div class="Formation">
                  <div class="info">
            
                  <?php
            $nomFichier = '."'".$data[0].'.txt'."'".';
            $contenu = file_get_contents($nomFichier);
            
            if ($contenu !== false) {
                echo $contenu;
            } else {
                echo "Aucune Donnée.";
            }
            ?>
            <form action="admin.php" method="POST">
              <input type="text" value="'.$data[0].'" name="titre" id="titre" style="display : none;">
              <input type="submit" value="Modifier">
            </form>
            
            
            
            
                  </div>
            
                  <div class="sticky">
                  <h1> Les prochaines sessions</h1>
                 
                  <input type="submit" value="Consultez les Dates et Villes"> <br>
           
                  L’IFJR met également en place des formations avec certaines Directions Interrégionales des Services Pénitentiaires DISP et Directions Territoriales de la Protection Judiciaire de la Jeunesse DTPPJ. L’inscription à ces formations est généralement réservée aux agents de ces DISP et DTPJJ. <br>
           
                  <?php
            $nomFichier = '."'".$data[0].'2.txt'."'".';
            $contenu = file_get_contents($nomFichier);
            
            if ($contenu !== false) {
                echo $contenu;
            } else {
                echo "Aucune Donnée.";
            }
            ?>
            <form action="admin.php" method="POST">
              <input type="text" value="'.$data[0].'2" name="titre" id="titre" style="display : none;">
              <input type="submit" value="Modifier">
            </form>
            
                  </div>
                </div>
              </body>
              </main>
              <footer>
  <?php
    include("../HeaderFooter/footer.php");
  ?>
</footer>
              </html>
            ';
                      $fichier = fopen($cheminAdmin, 'w');
                      fwrite($fichier, $texte);
                      fclose($fichier);
                      $texte = '<!DOCTYPE html>
            <html>
            <head>
    <meta charset="UTF-8" />
    <meta name="description" content="IFJR">
    <meta name="author" content="PLAUT-AUBRY Baptiste">
    <link rel="stylesheet" href="../CSS/InfoIFJR.css">
    <link rel="stylesheet" href="../CSS/Fichettes.css">
    <link rel="stylesheet" href="../HeaderFooter/header.css">
    <link rel="stylesheet" href="../HeaderFooter/footer.css">
    <link rel="stylesheet" href="../CSS/Formations.css">
    <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
    <title>Informations</title>
  </head>
  <main>
          <header>
            <?php
              include("../HeaderFooter/header.php");
            ?>
        </header>
            
                <body>           
                <div class="name">
                  Formation : '.$data[0].' – '.$data[1].'
                </div>
                <div class="Formation">
                  <div class="info">
            
                  <?php
            $nomFichier = '."'".$data[0].'.txt'."'".';
            $contenu = file_get_contents($nomFichier);
            
            if ($contenu !== false) {
                echo $contenu;
            } else {
                echo "Aucune Donnée.";
            }
            ?>
            
            
            
            
                  </div>
            
                  <div class="sticky">
                  <h1> Les prochaines sessions</h1>
                 
                  <input type="submit" value="Consultez les Dates et Villes"> <br>
             
                    L’IFJR met également en place des formations avec certaines Directions Interrégionales des Services Pénitentiaires DISP et Directions Territoriales de la Protection Judiciaire de la Jeunesse DTPPJ. L’inscription à ces formations est généralement réservée aux agents de ces DISP et DTPJJ. <br>
             
                    <?php
            $nomFichier = '."'".$data[0].'2.txt'."'".';
            $contenu = file_get_contents($nomFichier);
            
            if ($contenu !== false) {
                echo $contenu;
            } else {
                echo "Aucune Donnée.";
            }
            ?>
                  </div>
                </div>
              </body>
              </main>
              <footer>
            <?php
              include("../HeaderFooter/footer.php");
            ?>
          </footer>
              </html>
            ';
                      $fichier = fopen($chemin, 'w');
                      fwrite($fichier, $texte);
                      fclose($fichier);
                  }
              }
                
                fclose($handle);
            }
            
            ?>
      </div>
    </div>
    <h2 class="title"><center>DATES ET VILLES DE FORMATION</center></h2>
    <div class="block_line_container_date">
      <div class="container-box1 block" id="box"> <!-- PREMIERE BOX -->
                <a href="VillesFormations.php">
                <div class="block_content">
                    <h3>DATES ET VILLES</h3>
                    <div><em>Soyez au courant des formations à venir<span class = "arrow"></span></em></div>
                </div>
                </a>
      </div> <!-- FIN PREMIERE BOX -->
      <br>

  </div>
    <script type="text/javascript" src="NosFormations.js"></script>  <!-- JS DE L'ANIMATION DES BOXS -->
</body>

<footer>
  <?php
    include("../HeaderFooter/footer.php");
  ?>
</footer>

</html>
