<!DOCTYPE html>
<html>
<head>
<title>Modifier TxT</title>
<meta http-equiv="content-type" content="text/html; charset=utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<script src="js/tinymce/tinymce.min.js" type="text/javascript"></script>
<link rel="stylesheet" href="admin.css">
</head>
<body>
  <span id="c"><?php echo $_POST["titre"]; ?></span>
<div id="text" style="width:800px;margin:auto;">
  <textarea id="description" name="description">
  <?php
$nomFichier = $_POST["titre"].".txt";
$contenu = file_get_contents($nomFichier);

if ($contenu !== false) {
    echo $contenu;
} else {
    echo "Aucune Données";
}
?>

  </textarea>
</div>
<center>
<input type="button" value="VALIDER" onclick="ajouter()" />
</center>
<form action="enregistrer.php" method="POST" style="display: none;">
  <input type="text" id="res" value="" name="text">
  <input type="text" id="titre" value="" name="titre">
  <input type="submit" id="final">
</form>
<script type="text/javascript" language="javascript">
tinymce.init({
  width: 800,
  height: 500,
  statusbar: false,
  selector: "textarea",
  plugins: 'autolink lists link image charmap print preview anchor searchreplace visualblocks code fullscreen insertdatetime media table paste code help wordcount',
  toolbar: "bold italic | alignleft aligncenter alignright alignjustify | outdent indent | bullist numlist "
});
function ajouter()
{
tinymce.triggerSave(true, true);
var contenu = document.getElementById("description").value;
var elementPre = document.getElementById("res");
elementPre.value = contenu;
var elementtitre = document.getElementById("titre");
elementtitre.value = document.getElementById("c").textContent;
var boutonSoumission = document.getElementById("final");
boutonSoumission.click();
}
</script>



</body>
</html>
