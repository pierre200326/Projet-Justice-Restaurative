<!DOCTYPE html>
            <html>
            <head>
    <meta charset="UTF-8" />
    <meta name="description" content="IFJR">
    <meta name="author" content="PLAUT-AUBRY Baptiste">
    <link rel="stylesheet" href="../CSS/InfoIFJR.css">
    <link rel="stylesheet" href="../CSS/Fichettes.css">
    <link rel="stylesheet" href="../HeaderFooter/header.css">
    <link rel="stylesheet" href="../HeaderFooter/footer.css">
    <link rel="stylesheet" href="../CSS/Formations.css">
    <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
    <title>Informations</title>
  </head>
  <main>
          <header>
            <?php
              include("../HeaderFooter/header.php");
            ?>
        </header>
                <body>
                
                <div class="name">
                  Formation : Bénévoles de communauté – Devenir bénévole de la communauté
                </div>
                <div class="Formation">
                  <div class="info">
            
                  <?php
            $nomFichier = 'Bénévoles de communauté.txt';
            $contenu = file_get_contents($nomFichier);
            
            if ($contenu !== false) {
                echo $contenu;
            } else {
                echo "Aucune Donnée.";
            }
            ?>
            <form action="admin.php" method="POST">
              <input type="text" value="Bénévoles de communauté" name="titre" id="titre" style="display : none;">
              <input type="submit" value="Modifier">
            </form>
            
            
            
            
                  </div>
            
                  <div class="sticky">
                  <h1> Les prochaines sessions</h1>
                 
                  <form action="VillesFormationsAdmin.php">
                  <input type="submit" value="Consultez les Dates et Villes"> <br>
                  </form>           
                  <?php
            $nomFichier = 'Bénévoles de communauté2.txt';
            $contenu = file_get_contents($nomFichier);
            
            if ($contenu !== false) {
                echo $contenu;
            } else {
                echo "Aucune Donnée.";
            }
            ?>
            <form action="admin.php" method="POST">
              <input type="text" value="Bénévoles de communauté2" name="titre" id="titre" style="display : none;">
              <input type="submit" value="Modifier">
            </form>
            
                  </div>
                </div>
              </body>
              </main>
              <footer>
  <?php
    include("../HeaderFooter/footer.php");
  ?>
</footer>
              </html>
            