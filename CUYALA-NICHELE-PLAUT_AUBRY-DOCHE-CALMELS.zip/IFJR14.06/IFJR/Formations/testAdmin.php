<!DOCTYPE html>
            <html>
            <head>
    <meta charset="UTF-8" />
    <meta name="description" content="IFJR">
    <meta name="author" content="PLAUT-AUBRY Baptiste">
    <link rel="stylesheet" href="../CSS/InfoIFJR.css">
    <link rel="stylesheet" href="../CSS/Fichettes.css">
    <link rel="stylesheet" href="../HeaderFooter/header.css">
    <link rel="stylesheet" href="../HeaderFooter/footer.css">
    <link rel="stylesheet" href="../CSS/Formations.css">
    <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
    <title>Informations</title>
  </head>
  <main>
          <header>
            <?php
              include("../HeaderFooter/header.php");
            ?>
        </header>
                <body>
                
                <div class="name">
                  Formation : test – aaaa
                </div>
                <div class="Formation">
                  <div class="info">
            
                  <?php
            $nomFichier = 'test.txt';
            $contenu = file_get_contents($nomFichier);
            
            if ($contenu !== false) {
                echo $contenu;
            } else {
                echo "Aucune Donnée.";
            }
            ?>
            <form action="admin.php" method="POST">
              <input type="text" value="test" name="titre" id="titre" style="display : none;">
              <input type="submit" value="Modifier">
            </form>
            
            
            
            
                  </div>
            
                  <div class="sticky">
                  <h1> Les prochaines sessions</h1>
                 
                  <input type="submit" value="Consultez les Dates et Villes"> <br>
           
                  L’IFJR met également en place des formations avec certaines Directions Interrégionales des Services Pénitentiaires DISP et Directions Territoriales de la Protection Judiciaire de la Jeunesse DTPPJ. L’inscription à ces formations est généralement réservée aux agents de ces DISP et DTPJJ. <br>
           
                  <?php
            $nomFichier = 'test2.txt';
            $contenu = file_get_contents($nomFichier);
            
            if ($contenu !== false) {
                echo $contenu;
            } else {
                echo "Aucune Donnée.";
            }
            ?>
            <form action="admin.php" method="POST">
              <input type="text" value="test2" name="titre" id="titre" style="display : none;">
              <input type="submit" value="Modifier">
            </form>
            
                  </div>
                </div>
              </body>
              </main>
              <footer>
  <?php
    include("../HeaderFooter/footer.php");
  ?>
</footer>
              </html>
            