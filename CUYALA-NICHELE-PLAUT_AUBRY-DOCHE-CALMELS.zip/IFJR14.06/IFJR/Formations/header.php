<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Le Titre</title>
        <link rel="stylesheet" type="text/css" href="header.css" />
        <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@200&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css" integrity="..." crossorigin=""/>
        <script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js" integrity="..." crossorigin=""></script>

    </head>
    <body>
      <div class="header">
        <img src="IFJR.png" width="7%" alt="">
        <ul class="gauche">
          <li>
            <a href="https://www.justicerestaurative.org/">IFJR</a>
          </li>
          <li>
            <a href="https://www.justicerestaurative.org/">FORMATIONS</a>
          </li>
        </ul>
          <ul class="droite">
            <li>
              <a href="https://www.justicerestaurative.org/">CONNEXION</a>
            </li>
            <li>
              <a href="https://www.justicerestaurative.org/nous-contacter/">NOUS CONTACTER</a>
          </ul>
      </div>
      </body>
</html>
