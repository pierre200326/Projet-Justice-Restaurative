<!DOCTYPE html>
<html>
<head>
<title>enregistrement</title>
<meta http-equiv="content-type" content="text/html; charset=utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<span id="a"><?php echo $_POST["titre"]."Admin.php";?></span>
<?php
$nomFichier = $_POST["titre"].'.txt';
$contenu = $_POST["text"];
$monFichier = fopen($nomFichier, "w");
  fwrite($monFichier, $contenu);
  fclose($monFichier);



/*
if (file_put_contents($nomFichier, $contenu) !== false) {
    echo "Le contenu a été écrit dans le fichier avec succès !";
} else {
    echo "Une erreur s'est produite lors de l'écriture dans le fichier.";
}*/
?>
<script>
  var re = document.getElementById("a").innerHTML;
  window.location.href = "NosformationAdmin.php";
</script>
</body>
</html>
