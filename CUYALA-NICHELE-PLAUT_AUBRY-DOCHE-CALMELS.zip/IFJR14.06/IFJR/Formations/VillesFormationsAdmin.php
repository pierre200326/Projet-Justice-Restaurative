<!DOCTYPE html>
<html lang="fr">
  <head>
    <meta charset="UTF-8" />
    <meta name="description" content="IFJR">
    <meta name="author" content="PLAUT-AUBRY Baptiste">
    <link rel="stylesheet" href="../CSS/Fichettes.css">
    <link rel="stylesheet" href="../HeaderFooter/header.css">
    <link rel="stylesheet" href="../HeaderFooter/footer.css">
    <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
    <title>Formations</title>
  </head>

<main>
<header>
  <?php
    include("../HeaderFooter/header.php");
  ?>
</header>


<body>
  <div class="wrapper">
    <br>
    <h2 class="title"><center>DATES & VILLES</center></h2>
      <br>
    <div class="block_line_container_date">
      <div class="block_line_column">
            <?php
            if (($handle = fopen("ville.csv", "r")) !== FALSE) {
                while (($data = fgetcsv($handle, 1000, ";")) !== FALSE) {
                  $num = count($data);
                  echo '<div class="container-box1 block" id="box">';
                  echo '<a href="'.$data[2].'">';
                  echo '<div class="block_content">';
                  echo '<h3>'.$data[0].'</h3>';
                  echo '<div><em>'.$data[1].'<span class = "arrow"></span></em></div>';
                  echo '</div>';
                  echo '</a>';
                  echo '</div>';
                }
                fclose($handle);
            }
?>
      </div>
    </div>
    <center>
    <form action="ajouterVille.php" method="post">
        <label>Titre</label><input type="text" name="titre"><br><br>
        <label>Description</label><input type="text" name="des" style="width: 300px;"><br><br>
        <label>Lien</label><input type="text" name="lien" style="width: 300px;"><br><br>
        <input type="submit" value="Ajouter">
    </form>
    <br>
    <form action="supprimerVille.php" method="post">
        <label>Numéro à supprimer</label><input type="text" name="nbr">
        <input type="submit" value="Supprimer">
    </form>
    </center>
  </div>
    <script type="text/javascript" src="NosFormations.js"></script>  <!-- JS DE L'ANIMATION DES BOXS -->
</body>
</main>


<footer>
  <?php
    include("../HeaderFooter/footer.php");
  ?>
</footer>

</html>
