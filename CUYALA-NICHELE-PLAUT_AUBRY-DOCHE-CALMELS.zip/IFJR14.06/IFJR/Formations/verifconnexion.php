<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <?php
    echo "Connexionfsqf . . .";
    /*$loginOfficial="pierre200326";
    $passwordOfficial="Zinogre";*/
 echo $_POST["identifiant"] . "<br />\n";
 echo $_POST["password"] . "<br />\n";

    $row = 1;
if (($handle = fopen("mdp.csv", "r")) !== FALSE) {
    while (($data = fgetcsv($handle, 1000, ";")) !== FALSE) {
        $num = count($data);
        $row++;
        for ($c=0; $c < $num; $c++) {
            if ($c==0) {
              $loginOfficial=$data[$c];
            }
            if ($c==1) {
              $passwordOfficial=$data[$c];
            }
        }
        if (($loginOfficial==$_POST["identifiant"]) && ($passwordOfficial==$_POST["password"])){
          /* si c'est bon je pars sur la page accueil.php */
          header('Location: ../Frontpage/Frontpage.php');
              exit();
            }
    }
    header('Location: connexion.php');
    fclose($handle);
}
/*
    if (($loginOfficial==$_POST["Identifiant"]) && ($passwordOfficial==$_POST["Password"])){
      /* si c'est bon je pars sur la page accueil.php */
      /*    header('Location: accueil.php?Identifiant='.$_POST["Identifiant"]);
          exit();
        }
        else{
          header('Location: connexion.html');
      } */
?>
  </body>
</html>
