<!DOCTYPE html>
<html lang="fr">
  <head>
    <meta charset="UTF-8" />
    <meta name="description" content="IFJR">
    <meta name="author" content="PLAUT-AUBRY Baptiste">
    <link rel="stylesheet" href="../CSS/InfoIFJR.css">
    <link rel="stylesheet" href="../CSS/Fichettes.css">
    <link rel="stylesheet" href="../HeaderFooter/header.css">
    <link rel="stylesheet" href="../HeaderFooter/footer.css">
    <link rel="stylesheet" href="deroule.css" />
    <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
    <title>Informations</title>
  </head>


<main>
<header>
    <?php
      include("../HeaderFooter/header.php");
    ?>
</header>

<body>
  <div class="wrapper">
  <h2 class="title"><center>INFORMATIONS</center></h2>
    <div class="TextBox">
      <p>Depuis 2011, l’Institut Français pour la Justice Restaurative (IFJR) et <a href="https://www.france-victimes.fr/">France Victimes</a> organisent des formations à
        l’animation des rencontres restauratives pour les professionnels de l’aide aux victimes, de l’administration pénitentiaire et de la protection judiciaire de la jeunesse, notamment. </p>

      <p>En 2015, l’IFJR et France Victimes ont conclu un nouveau partenariat, avec <a href="https://www.enap.justice.fr/">l’École Nationale d’administration pénitentiaire</a> (ÉNAP),
      permettant la création d’un véritable parcours de formation pour les animateurs de rencontres restauratives.</p>

      <p>Unique en France, il s’inscrit pleinement dans un mouvement de généralisation des programmes de justice restaurative sur l’ensemble du territoire.

      Les chiffres depuis 2011 (mise à jour 2021) :</p>

      <center><img src="https://i0.wp.com/www.justicerestaurative.org/wp-content/uploads/2023/01/Capture-decran-2023-01-27-a-17.36.50.png" width="50%" ></center>

      <p><h3>Nous contacter :</h3></p>

      <p><a href="mailto:formation@justicerestaurative.org"> formation@justicerestaurative.org</a> / 05 59 27 46 88 </p>

      <p><h3>Personnes en situation de handicap :</h3></p>

      <p>Toutes nos formations sont ouvertes aux personnes en situation de handicap. La faisabilité des adaptations à envisager sera étudiée en fonction des besoins communiqués par l’apprenant.</p>

      <p>Contactez <a href="mailto:referent-handicap@justicerestaurative.org">referent-handicap@justicerestaurative.org </a></p>
    </div>
    
  </div>
  <?php
      include("deroule.php");
    ?>
</body>
</main>

<footer>
  <?php
    include("../HeaderFooter/footer.php");
  ?>
</footer>

</html>
